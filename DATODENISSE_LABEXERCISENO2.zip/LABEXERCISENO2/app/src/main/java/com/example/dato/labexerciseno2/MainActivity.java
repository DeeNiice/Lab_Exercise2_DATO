package com.example.dato.labexerciseno2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

   // private Button button;

    EditText etuniv1, etuniv2, etuniv3, etuniv4, etuniv5, etuniv6, etuniv7, etuniv8;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       // button = findViewById(R.id.button2);

        etuniv1 = findViewById(R.id.editText);
        etuniv2 = findViewById(R.id.editText2);
        etuniv3 = findViewById(R.id.editText3);
        etuniv4 = findViewById(R.id.editText4);
        etuniv5 = findViewById(R.id.editText5);
        etuniv6 = findViewById(R.id.editText6);
        etuniv7 = findViewById(R.id.editText7);
        etuniv8 = findViewById(R.id.editText8);
    }

    public void saveData(View v){
        sp = getSharedPreferences("data1", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();

        String univ1 = etuniv1.getText().toString();
        String univ2 = etuniv2.getText().toString();
        String univ3 = etuniv3.getText().toString();
        String univ4 = etuniv4.getText().toString();
        String univ5 = etuniv5.getText().toString();
        String univ6 = etuniv6.getText().toString();
        String univ7 = etuniv7.getText().toString();
        String univ8 = etuniv8.getText().toString();

        editor.putString("univ1", univ1);
        editor.putString("univ2", univ2);
        editor.putString("univ3", univ3);
        editor.putString("univ4", univ4);
        editor.putString("univ5", univ5);
        editor.putString("univ6", univ6);
        editor.putString("univ7", univ7);
        editor.putString("univ8", univ8);
        editor.commit();

        Toast.makeText(this, "data was saved!", Toast.LENGTH_LONG).show();
    }

    /*public void verify(View v){

        sp = getSharedPreferences("data1", MODE_PRIVATE);
        String univ1SP= sp.getString("univ1", null);
        String univ2SP= sp.getString("univ2", null);
        String univ3SP= sp.getString("univ3", null);
        String univ4SP= sp.getString("univ4", null);
        String univ5SP= sp.getString("univ5", null);
        String univ6SP= sp.getString("univ6", null);
        String univ7SP= sp.getString("univ7", null);
        String univ8SP= sp.getString("univ8", null);

        String univ1 = etuniv1.getText().toString();
        String univ2 = etuniv2.getText().toString();
        String univ3 = etuniv3.getText().toString();
        String univ4 = etuniv4.getText().toString();
        String univ5 = etuniv5.getText().toString();
        String univ6 = etuniv6.getText().toString();
        String univ7 = etuniv7.getText().toString();
        String univ8 = etuniv8.getText().toString();

        if(univ1SP.equals(univ1) && univ2SP.equals(univ2) && univ3SP.equals(univ3) && univ4SP.equals(univ4) && univ5SP.equals(univ5) && univ6SP.equals(univ6) && univ7SP.equals(univ7) && univ8SP.equals(univ8)){

            Toast.makeText(this, "SCHOOL IS COMPETING IN UAAP", Toast.LENGTH_LONG).show();
        } else{

            Toast.makeText(this, "SCHOOL IS NOT PART OF UAAP", Toast.LENGTH_LONG).show();
        }
    }*/

    public void buttonOnClick(View v){
        Button button=(Button) v;
        startActivity(new Intent(getApplicationContext(), Main2Activity.class));
    }
}
